/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50719
Source Host           : localhost:3306
Source Database       : qgchat

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2018-07-26 10:50:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `qg_user`
-- ----------------------------
DROP TABLE IF EXISTS `qg_user`;
CREATE TABLE `qg_user` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `account` varchar(20) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `iconURL` varchar(100) DEFAULT NULL,
  `hx_account` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`) USING BTREE,
  UNIQUE KEY `hx_account` (`hx_account`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qg_user
-- ----------------------------
INSERT INTO `qg_user` VALUES ('0000000048', '17754011757', '123456', '唐贝贝', 'http://139.199.158.151/qgchat/files/images/17754011757.jpg', '17754011757');
INSERT INTO `qg_user` VALUES ('0000000049', '18895368589', '123456', '马山水', 'http://139.199.158.151/qgchat/files/images/18895368589.jpg', '18895368589');

-- ----------------------------
-- Table structure for `qg_user_group`
-- ----------------------------
DROP TABLE IF EXISTS `qg_user_group`;
CREATE TABLE `qg_user_group` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) DEFAULT '我的好友',
  `account` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account` (`account`),
  CONSTRAINT `qg_user_group_ibfk_1` FOREIGN KEY (`account`) REFERENCES `qg_user` (`account`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qg_user_group
-- ----------------------------
INSERT INTO `qg_user_group` VALUES ('0000000021', '我的好友', '17754011757');
INSERT INTO `qg_user_group` VALUES ('0000000022', '我的好友', '18895368589');

-- ----------------------------
-- Table structure for `qg_user_group_list`
-- ----------------------------
DROP TABLE IF EXISTS `qg_user_group_list`;
CREATE TABLE `qg_user_group_list` (
  `id` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) DEFAULT '我的好友',
  `friend_account` varchar(20) DEFAULT NULL,
  `account` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account` (`account`),
  CONSTRAINT `qg_user_group_list_ibfk_2` FOREIGN KEY (`account`) REFERENCES `qg_user_group` (`account`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qg_user_group_list
-- ----------------------------
INSERT INTO `qg_user_group_list` VALUES ('0000000025', '我的好友', '17754011757', '18895368589');
